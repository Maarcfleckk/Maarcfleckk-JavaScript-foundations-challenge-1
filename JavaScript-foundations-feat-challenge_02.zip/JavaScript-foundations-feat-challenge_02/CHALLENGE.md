# JavaScript Basics

## Description

This challenge involves primitive types and operators.

## Requirements

1. CreaUpdatete file `index.html` with `<script>` tags for all JS files.
2. Complete all required exercises.
