/* 
   Create a constant variable of each of the following primitive types:
   - String
   - Number
   - Boolean
   - Null
   - Undefined

   Log out each variable to the terminal at the end.
*/
